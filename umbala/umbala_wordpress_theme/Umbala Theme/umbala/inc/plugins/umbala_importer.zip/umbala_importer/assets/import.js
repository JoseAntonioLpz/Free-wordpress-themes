(function($) {
    "use strict";

    $('#umbala-importer .nav-tab-wrapper a').on('click', function(e) {
        var clicked = $(this).attr('href');
        if (clicked.indexOf('#') == -1) {
            return true;
        }
        $('#umbala-importer .nav-tab-wrapper a').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active').blur();
        $('.group').hide();
        $(clicked).fadeIn();
        e.preventDefault();
    });

    $('#umbala-importer .option label').on('click', function() {
        var checkbox = $(this).find('input[type="checkbox"]');
        if (checkbox.is(':checked')) {
            $(this).addClass('is-checked');
        } else {
            $(this).removeClass('is-checked');
        }

        umbala_import_button();
    });

    function umbala_import_button() {
        var disabled = true;
        $('#umbala-importer .option input[type="checkbox"]').each(function() {
            if ($(this).is(':checked')) {
                disabled = false;
                return;
            }
        });
        $('#umbala-import-button').attr('disabled', disabled);
    }

    $('#umbala-import-button').on('click', function() {
        $('#umbala-importer .loading').show();
        var options = {
            theme_options: $('#umbala_import_theme_options').is(':checked'),
            widgets: $('#umbala_import_widget').is(':checked'),
            revsliders: $('#umbala_import_revslider').is(':checked'),
            demo_content: $('#umbala_import_demo_content').is(':checked')
        };

        umbala_import_options(options);
    });

    function umbala_import_options(options) {
        if (options.theme_options) {
            var data = { 'action': 'umbala_import_theme_options' };

            $.post(ajaxurl, data, function(response) {
                umbala_import_message('Import Theme Options sucessfully.');
                umbala_import_widgets(options);
            }).fail(function(response) {
                umbala_import_widgets(options);
            });
        } else {
            umbala_import_widgets(options);
        }
    }

    function umbala_import_widgets(options) {
        if (options.widgets) {
            var data = { 'action': 'umbala_import_widget' };

            $.post(ajaxurl, data, function(response) {
                umbala_import_message('Import Widgets sucessfully.');
                umbala_import_revsliders(options);
            }).fail(function(response) {
                umbala_import_revsliders(options);
            });
        } else {
            umbala_import_revsliders(options);
        }
    }

    function umbala_import_revsliders(options) {
        if (options.revsliders) {
            var data = { 'action': 'umbala_import_revslider' };

            $.post(ajaxurl, data, function(response) {
                umbala_import_message('Import Revolution slider sucessfully.');
                umbala_import_content(options);
            }).fail(function(response) {
                umbala_import_content(options);
            });
        } else {
            umbala_import_content(options);
        }
    }

    function umbala_import_content(options) {
        if (options.demo_content) {
            var data = { 'action': 'umbala_import_content' };

            $.post(ajaxurl, data, function(response) {
                umbala_import_message('Import Demo Content sucessfully.');
                umbala_import_config(options);
            }).fail(function(response) {
                umbala_import_message('Import Demo Content Fail!');
            });
        } else {
            umbala_import_finish();
        }
    }

    function umbala_import_config(options) {
        if (options.demo_content) {
            var data = { 'action': 'umbala_import_config' };

            $.post(ajaxurl, data, function(response) {
                umbala_import_finish();
            }).fail(function(response) {
                umbala_import_finish();
            });
        } else {
            umbala_import_finish();
        }
    }

    function umbala_import_finish() {
        $('#umbala-importer .loading').hide();
        umbala_import_message('Success!!!');
    }

    function umbala_import_message(message) {
        var message_wrapper = $('#umbala-importer .messages');
        message_wrapper.append('<p>' + message + '</p>');
    }

})(jQuery);