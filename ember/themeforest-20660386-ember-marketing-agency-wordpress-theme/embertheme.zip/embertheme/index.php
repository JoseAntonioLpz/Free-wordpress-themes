<?php get_header(); ?>
<?php get_template_part('includes/blog'); ?>
<?php get_footer(); ?>

