<section class="section not-found">
	<div class="container">
		<h4><?php esc_html_e( 'No results were found for the requested page.', 'embertheme' ); ?></h4>
	</div>
</section>