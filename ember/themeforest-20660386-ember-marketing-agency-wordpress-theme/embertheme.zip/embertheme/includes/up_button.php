<!-- Up button -->
<div class="btn-up">
	<div class="fa fa-angle-up"></div>
</div>