<?php

if ( class_exists( 'kc_tools' ) ) {
	$forms = kc_tools::get_cf7_names();
} else {
	$forms = '';
}

if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_differ_contact_form7' => array(
				'name'        => __( 'Contact Form 7', 'differ_kc' ),
				'title'       => __( 'Contact Form 7', 'differ_kc' ),
				'description' => __( 'Contact Form 7', 'differ_kc' ),
				'icon'        => 'ember-cf7',
				'category'    => 'Ember',
				'css_box'     => true,
				'params'      => array(
					'general' => array(

						array(
							'name'    => 'form',
							'label'   => __( 'Select Form', 'differ_kc' ),
							'type'    => 'select',
							'options' => $forms
						),

					),
					'styles'  => array(
						array(
							'name'  => 'kc_differ_contact_form7_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)
				)
			)
		)
	);


}
