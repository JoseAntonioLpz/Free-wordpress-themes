<?php


if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_youtube_video' => array(
				'name'        => __( 'YouTube Video', 'differ_kc' ),
				'title'       => __( 'YouTube Video', 'differ_kc' ),
				'description' => __( 'YouTube Video', 'differ_kc' ),
				'icon'        => 'ember-youtube-video',
				'category'    => 'Content',
				'css_box'     => true,
				'params'      => array(
					'general' => array(

						array(
							'name'  => 'link',
							'label' => __( 'YouTube Video Link', 'differ_kc' ),
							'type'  => 'text',
							'value' => 'https://www.youtube.com/watch?v=JZRsMRg39QY',
						),

						array(
							'name'        => 'start',
							'label'       => __( 'Video Start Time', 'differ_kc' ),
							'type'        => 'text',
							'value'       => '0:00',
							'description' => __( 'Insert time start, example 1:15', 'differ_kc' )
						),

						array(
							'name'        => 'similar_videos',
							'label'       => 'Similar Videos',
							'type'        => 'toggle',
							'value'       => 'no',
							'description' => 'Show similar videos when finished watching',
						),
						array(
							'name'  => 'control',
							'label' => 'Show Player Control Panel',
							'type'  => 'toggle',
							'value' => 'yes',
						),
						array(
							'name'  => 'title_action_bar',
							'label' => 'Show video title and action bar',
							'type'  => 'toggle',
							'value' => 'yes',
						),
						array(
							'name'  => 'privacy',
							'label' => 'Enable privacy mode',
							'type'  => 'toggle',
							'value' => 'no',
						)

					),
					'styles'  => array(
						array(
							'name'  => 'differ_buttons_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)
				)
			)
		)
	);


}
