<?php
if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_clients_slider' => array(
				'name'        => __( 'Clients/Partners Slider', 'differ_kc' ),
				'title'       => __( 'Clients/Partners Slider', 'differ_kc' ),
				'description' => __( 'Clients/Partners Slider', 'differ_kc' ),
				'icon'        => 'ember-clients-slider',
				'category'    => 'Ember',
				'css_box'     => true,
				'params'      => array(
					'general' => array(
						array(
							'name'    => 'img_height',
							'label'   => __( 'Image Height', 'differ_kc' ),
							'type'    => 'number_slider',
							'options' => array(
								'min'        => 20,
								'max'        => 300,
								'unit'       => 'px',
								'show_input' => true
							),
							'value'   => '70px',
						),

						array(
							'name'        => 'xl_cols',
							'label'       => __( '1200px+ Columns Count', 'differ_kc' ),
							'type'        => 'number_slider',
							'options'     => array(
								'min'        => 1,
								'max'        => 10,
								'show_input' => true
							),
							'value'       => '5',
							'description' => __( 'Select how many columns display in 1200px +', 'differ_kc' ),
						),

						array(
							'name'        => 'lg_cols',
							'label'       => __( '992px+ Columns Count ', 'differ_kc' ),
							'type'        => 'number_slider',
							'options'     => array(
								'min'        => 1,
								'max'        => 10,
								'show_input' => true
							),
							'value'       => '4',
							'description' => __( 'Select how many columns display in 992px +', 'differ_kc' ),
						),

						array(
							'name'        => 'md_cols',
							'label'       => __( '768px+ Columns Count ', 'differ_kc' ),
							'type'        => 'number_slider',
							'options'     => array(
								'min'        => 1,
								'max'        => 5,
								'show_input' => true
							),
							'value'       => '3',
							'description' => __( 'Select how many columns display in 768px +', 'differ_kc' ),
						),

						array(
							'name'        => 'sm_cols',
							'label'       => __( '560px+ Columns Count ', 'differ_kc' ),
							'type'        => 'number_slider',
							'options'     => array(
								'min'        => 1,
								'max'        => 5,
								'show_input' => true
							),
							'value'       => '2',
							'description' => __( 'Select how many columns display in 560px +', 'differ_kc' ),
						),

						array(
							'name'        => 'xs_cols',
							'label'       => __( '560px- Columns Count ', 'differ_kc' ),
							'type'        => 'number_slider',
							'options'     => array(
								'min'        => 1,
								'max'        => 3,
								'show_input' => true
							),
							'value'       => '1',
							'description' => __( 'Select how many columns display in 560px-', 'differ_kc' ),
						),


						array(
							'type'    => 'group',
							'label'   => __( 'Logos', 'differ_kc' ),
							'name'    => 'logos',
							'options' => array( 'add_text' => __( 'Add new Logo', 'differ_kc' ) ),
							'params'  => array(
								array(
									'type'        => 'text',
									'label'       => __( 'Title', 'differ_kc' ),
									'name'        => 'title',
									'admin_label' => true,
								),
								array(
									'name'        => 'image',
									'label'       => __( 'Image', 'differ_kc' ),
									'type'        => 'attach_image',
									'description' => 'Upload clinet/partner logo',
								),
								array(
									'type'        => 'text',
									'label'       => __( 'Link', 'differ_kc' ),
									'name'        => 'link',
									'admin_label' => true,
									'description' => __( 'Insert clinet/partner link (not required)', 'differ_kc' ),
								),
							)
						)


					),
					'styles'  => array(
						array(
							'name'  => 'differ_buttons_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)
				)
			)
		)
	);

}