<?php


if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_hero_slider' => array(
				'name'         => __( 'Hero Slider', 'kingcomposer' ),
				'description'  => __( 'Hero Slider', 'kingcomposer' ),
				'category'     => 'Ember',
				'icon'         => 'ember-hero-slider',
				'title'        => __( 'Hero Slider', 'kingcomposer' ),
				'is_container' => true,
				'css_box'      => true,
				'views'        => array(
					'type'     => 'views_sections',
					'sections' => 'kc_hero_slide'
				),


				'params' => array(
					'settings' => array(
						array(
							'name'        => 'slide_speed',
							'label'       => __( 'Slide Speed', 'differ_kc' ),
							'type'        => 'number_slider',  // USAGE RADIO TYPE
							'options'     => array(    // REQUIRED
								'min'        => 100,
								'max'        => 1000,
								'show_input' => true
							),
							'value'       => '300',
							'description' => __( 'Duration of transition between slides (in ms)', 'differ_kc' ),
						),
						array(
							'name'        => 'efect',
							'label'       => __( 'Slider Animation Effect', 'differ_kc' ),
							'type'        => 'select',
							'options'     => array(
								'slide'     => 'slide',
								'fade'      => 'fade',
								'coverflow' => 'coverflow',
								'flip'      => 'flip',
								'cube'      => 'cube',
							),
							'value'       => 'fade',
							'description' => __( 'Tranisition effect. Could be "slide", "fade", "cube", "coverflow" or "flip"', 'differ_kc' ),
						),
						array(
							'name'        => 'grab_cursor',
							'label'       => __( 'Grab Cursor', 'differ_kc' ),
							'type'        => 'toggle',
							'value'       => 'no',
							'description' => __( 'This option may a little improve desktop usability. If true, user will see the "grab" cursor when hover on Swiper', 'differ_kc' ),
						),
						array(
							'name'        => 'loop',
							'label'       => __( 'Loop', 'differ_kc' ),
							'type'        => 'toggle',
							'value'       => 'yes',
							'description' => __( 'Set to true to enable continuous loop mode', 'differ_kc' ),
						),
						array(
							'name'  => 'autoplay',
							'label' => __( 'Autoplay', 'differ_kc' ),
							'type'  => 'toggle',
							'value' => 'yes',
						),
						array(
							'name'        => 'delay',
							'label'       => __( 'Autoplay Delay', 'differ_kc' ),
							'type'        => 'number_slider',  // USAGE RADIO TYPE
							'options'     => array(    // REQUIRED
								'min'        => 500,
								'max'        => 15000,
								'show_input' => true
							),
							'value'       => '3000',
							'description' => __( 'Duration of transition between slides (in ms)', 'differ_kc' ),
							'relation'    => array(
								'parent'    => 'autoplay',
								'show_when' => 'yes'
							)
						),
						array(
							'name'  => 'pagination',
							'label' => __( 'Pagination', 'differ_kc' ),
							'type'  => 'toggle',
							'value' => 'yes',
						),
						array(
							'name'  => 'arrows',
							'label' => __( 'Arrows', 'differ_kc' ),
							'type'  => 'toggle',
							'value' => 'yes',
						),
					),
					'styles'   => array(
						array(
							'name'  => 'hero_slider_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)
				),
				'content' => '[kc_hero_slide title="Slide"][/kc_hero_slide]'
			),
		)
	);


}
