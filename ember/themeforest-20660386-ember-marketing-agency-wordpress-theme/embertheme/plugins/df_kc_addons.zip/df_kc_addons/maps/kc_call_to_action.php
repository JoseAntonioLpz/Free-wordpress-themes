<?php
if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_call_to_action' => array(
				'name'       => __( 'Call to Action', 'differ_kc' ),
				'title'      => __( 'Call to Action', 'differ_kc' ),
				'icon'       => 'ember-call-to-action',
				'category'   => 'Ember',
				'css_box'    => true,
				'params'     => array(
					'general' => array(
						array(
							'name'  => 'bg_image',
							'label' => __( 'Background Image', 'differ_kc' ),
							'type'  => 'attach_image',
						),
						array(
							'name'  => 'parallax',
							'label' => __( 'User parallax', 'differ_kc' ),
							'type'  => 'toggle',
							'value' => 'no',
						),
						array(
							'name'  => 'title',
							'label' => __( 'Insert Text', 'differ_kc' ),
							'type'  => 'text',
						),
						array(
							'name'    => 'btn_size',
							'label'   => __( 'Button Size', 'differ_kc' ),
							'type'    => 'select',
							'options' => array(
								'size-default' => __( 'Default', 'differ_kc' ),
								'size-big'     => __( 'Big', 'differ_kc' ),
								'size-small'   => __( 'Small', 'differ_kc' ),
							),
							'value'   => 'default',
						),
						array(
							'name'    => 'btn_color',
							'label'   => __( 'Button Color', 'differ_kc' ),
							'type'    => 'select',
							'options' => array(
								'black'   => __( 'Black', 'differ_kc' ),
								'white'   => __( 'White', 'differ_kc' ),
								'primary' => __( 'Primary Color', 'differ_kc' ),
							),
							'value'   => 'black',
						),
						array(
							'name'    => 'btn_hover_color',
							'label'   => __( 'Button Hover Color', 'differ_kc' ),
							'type'    => 'select',
							'options' => array(
								'hover-black'   => __( 'Black', 'differ_kc' ),
								'hover-white'   => __( 'White', 'differ_kc' ),
								'hover-primary' => __( 'Primary Color', 'differ_kc' ),
							),
							'value'   => 'black',
						),
						array(
							'name'    => 'btn_style',
							'label'   => __( 'Button Style', 'differ_kc' ),
							'type'    => 'select',
							'options' => array(
								'style-primary'      => __( 'Primary', 'differ_kc' ),
								'style-primary-fill' => __( 'Primary Fill', 'differ_kc' ),
								'style-black'        => __( 'Black', 'differ_kc' ),
								'style-black-fill'   => __( 'Black Fill', 'differ_kc' ),
								'style-white'        => __( 'White', 'differ_kc' ),
								'style-white-fill'   => __( 'White Fill', 'differ_kc' ),
							),
							'value'   => 'black',
						),
						array(
							'name'    => 'btn_radius',
							'label'   => __( 'Button Radius', 'differ_kc' ),
							'type'    => 'select',
							'options' => array(
								'rect'    => __( 'Rectangle', 'differ_kc' ),
								'rounded' => __( 'Rounded', 'differ_kc' ),
							),
							'value'   => 'default',
						),
						array(
							'name'  => 'btn_link',
							'label' => __( 'Button Link', 'differ_kc' ),
							'type'  => 'link',
						)
					),
				)
			)
		)
	);


}