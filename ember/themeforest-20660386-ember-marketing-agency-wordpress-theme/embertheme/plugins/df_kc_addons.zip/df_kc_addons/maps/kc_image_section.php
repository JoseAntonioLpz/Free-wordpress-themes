<?php


if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_image_section' => array(
				'name'        => __( 'Image Section', 'differ_kc' ),
				'title'       => __( 'Image Section', 'differ_kc' ),
								'description' => __( 'Image Section', 'differ_kc' ),
				'icon'        => 'ember-image-section',
				'category'    => 'Ember',
				'css_box'     => true,
				'params'      => array(
					'general' => array(
						array(
							'name'  => 'image',
							'label' => __( 'Image', 'differ_kc' ),
							'type'  => 'attach_image',
						),
						array(
							'name'  => 'text',
							'label' => __( 'Content', 'differ_kc' ),
							'type'  => 'editor',
						),
					),
					'styles'  => array(
						array(
							'name'  => 'image_section_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)
				)
			)
		)
	);


}
