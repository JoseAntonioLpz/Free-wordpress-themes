<?php


$posts = array();
foreach ( get_posts() as $post ):
	$posts[ $post->ID ] = $post->post_title;
endforeach;

if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_latest_blog' => array(
				'name'        => __( 'Latest Blog', 'differ_kc' ),
				'title'       => __( 'Latest Blog', 'differ_kc' ),
								'description' => __( 'Latest Blog Posts', 'differ_kc' ),
				'icon'        => 'ember-latest-blog',
				'category'    => 'Ember',
				'css_box'     => true,
				'params'      => array(
					'general' => array(
						array(
							'name'    => 'posts_count',
							'label'   => __( 'Posts Count', 'differ_kc' ),
							'type'    => 'number_slider',
							'options' => array(
								'min'        => 2,
								'max'        => 9,
								'show_input' => true
							),

							'value' => '3',
							'relation' => array(
								'parent'    => 'select_enable',
								'show_when' => 'no'
							)
						),

						array(
							'name'        => 'select_enable',
							'label'       => 'Select Posts?',
							'type'        => 'toggle',
							'value'       => 'no',
							'description' => __( 'Display latest posts or select posts', 'differ_kc' ),
						),

						array(
							'name'     => 'posts',
							'label'    => __( 'Select Posts', 'differ_kc' ),
							'type'     => 'multiple',
							'options'  => $posts,
							'relation' => array(
								'parent'    => 'select_enable',
								'show_when' => 'yes'
							)
						),

						array(
							'name'    => 'cols_count',
							'label'   => __( 'Columns Count', 'differ_kc' ),
							'type'    => 'select',
							'options' => array(
								'2' => __( '2 Columns', 'differ_kc' ),
								'3' => __( '3 Columns', 'differ_kc' ),
								'4' => __( '4 Columns', 'differ_kc' )
							),
							'value'   => '3',
						),

						array(
							'name'    => 'title_crop',
							'label'   => __( 'Title Trim Words', 'differ_kc' ),
							'type'    => 'number_slider',
							'options' => array(
								'min'        => 1,
								'max'        => 20,
								'show_input' => true
							),

							'value' => '6',
						),

						array(
							'name'    => 'excerpt_crop',
							'label'   => __( 'Excerpt Trim Words', 'differ_kc' ),
							'type'    => 'number_slider',
							'options' => array(
								'min'        => 1,
								'max'        => 100,
								'show_input' => true
							),

							'value' => '20',
						),
						array(
							'name'    => 'img_height',
							'label'   => __( 'Image Height', 'differ_kc' ),
							'type'    => 'number_slider',
							'options' => array(
								'min'        => 120,
								'max'        => 600,
								'show_input' => true
							),
							'value'   => '230',
						),

					),
					'styles'  => array(
						array(
							'name'  => 'differ_buttons_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)
				)
			)
		)
	);


}
