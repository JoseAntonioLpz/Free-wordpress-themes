<?php


if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_contact_links' => array(
				'name'        => __( 'Contact Links', 'differ_kc' ),
				'title'       => __( 'Contact Links', 'differ_kc' ),
				'description' => __( 'Contact Links', 'differ_kc' ),
				'icon'        => 'ember-contact-links',
				'category'    => 'Ember',
				'css_box'     => true,
				'params' => array(
					'general' => array(
						array(
							'type'    => 'group',
							'label'   => __( 'Links', 'differ_kc' ),
							'name'    => 'links',
							'options' => array( 'add_text' => __( 'Add new link', 'differ_kc' ) ),
							'params'  => array(
								array(
									'type'  => 'icon_picker',
									'label' => 'Select Icon',
									'name'  => 'icon',
								),
								array(
									'name'  => 'link',
									'label' => 'Link',
									'type'  => 'link',
								)

							)
						)
					),
					'styles' => array(
						array(
							'name'  => 'kc_contact_links_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)
				),

			)
		)
	);


}
