<?php


if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_differ_google_map' => array(
				'name'        => __( 'Google Map', 'differ_kc' ),
				'title'       => __( 'Google Map', 'differ_kc' ),
				'description' => __( 'Google Map', 'differ_kc' ),
				'icon'        => 'ember-google-map',
				'category'    => 'Ember',
				'params'      => array(
					'general' => array(
						array(
							'name'        => 'api_key',
							'label'       => 'Google Api Key',
							'type'        => 'text',
							'description' => 'Please generate your Google Api key for Google Map. <a href="https://developers.google.com/maps/documentation/javascript/get-api-key">Google Console<a/>',
						),
						array(
							'name'    => 'map_height',
							'label'   => __( 'Map Height', 'differ_kc' ),
							'type'    => 'number_slider',
							'options' => array(    // REQUIRED
								'min'        => 100,
								'max'        => 1000,
								'show_input' => true
							),
							'value'   => '500',
						),
						array(
							'name'  => 'map_width',
							'label' => 'Force Fullwidth',
							'type'  => 'toggle',
							'value' => 'yes',
						),
						array(
							'name'    => 'zoom',
							'label'   => __( 'Map Zoom', 'differ_kc' ),
							'type'    => 'number_slider',
							'options' => array(    // REQUIRED
								'min'        => 1,
								'max'        => 100,
								'show_input' => true
							),
							'value'   => '7',
						),
						array(
							'name'        => 'latitude',
							'label'       => 'Map Latitude',
							'type'        => 'text',
							'description' => 'Use <a href="https://www.gps-coordinates.net/">https://www.gps-coordinates.net/</a>',
						),
						array(
							'name'        => 'longitude',
							'label'       => 'Map Longitude',
							'type'        => 'text',
							'description' => 'Use <a href="https://www.gps-coordinates.net/">https://www.gps-coordinates.net/</a>',
						),
						array(
							'name'        => 'style',
							'label'       => 'Map Style',
							'type'        => 'textarea',
							'description' => 'Insert Map style JSON array from <a target="_blank" href="https://snazzymaps.com/">https://snazzymaps.com/</a> or <a href="https://mapstyle.withgoogle.com/">https://mapstyle.withgoogle.com/</a>',
						),
						array(
							'name' => 'map_pin_icon',
							'label' => 'Pin Icon',
							'type' => 'attach_image',
						),
						array(
							'type'        => 'group',
							'label'       => __( 'Markers', 'differ_kc' ),
							'name'        => 'markers',
							'description' => '',
							'options'     => array( 'add_text' => __( 'Add new Marker', 'differ_kc' ) ),
							'params'      => array(
								array(
									'name'        => 'latitude',
									'label'       => 'Marker Latitude',
									'type'        => 'text',
									'description' => 'Use <a href="https://www.gps-coordinates.net/">https://www.gps-coordinates.net/</a>',
								),
								array(
									'name'        => 'longitude',
									'label'       => 'Marker Longitude',
									'type'        => 'text',
									'description' => 'Use <a href="https://www.gps-coordinates.net/">https://www.gps-coordinates.net/</a>',
								),
								array(
									'name'        => 'content',
									'label'       => 'Infowindow',
									'type'        => 'textarea',
									'description' => 'Tooltip on marker click',
								)
							)
						)
					),


				),
				'styles'      => array(
					array(
						'name'  => 'differ_buttons_css',
						'label' => __( 'Styles', 'differ_kc' ),
						'type'  => 'css',
					)
				)
			)
		)
	);


}
