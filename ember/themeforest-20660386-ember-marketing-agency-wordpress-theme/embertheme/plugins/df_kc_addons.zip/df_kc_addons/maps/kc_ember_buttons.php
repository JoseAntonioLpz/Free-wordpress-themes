<?php

if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_ember_buttons' => array(
				'name'        => __( 'Ember Button', 'differ_kc' ),
				'title'       => __( 'Ember Button', 'differ_kc' ),
								'description' => __( 'Buttons Wrapper', 'differ_kc' ),
				'icon'        => 'ember-button-icon',
				'category'    => 'Ember',
				'css_box'     => true,
				'params'      => array(
					'general' => array(
						array(
							'name'    => 'alignment',
							'label'   => __( 'Select Alignment', 'differ_kc' ),
							'type'    => 'select',
							'options' => array(
								'center' => __( 'Center', 'differ_kc' ),
								'left'   => __( 'Left', 'differ_kc' ),
								'right'  => __( 'Right', 'differ_kc' ),
							),
							'value'   => 'center',
						),
						array(
							'type'        => 'group',
							'label'       => __( 'Buttons', 'differ_kc' ),
							'name'        => 'buttons',
							'description' => '',
							'options'     => array( 'add_text' => __( 'Add Button', 'differ_kc' ) ),
							'params'      => array(
								array(
									'name'    => 'btn_size',
									'label'   => __( 'Button Size', 'differ_kc' ),
									'type'    => 'select',
									'options' => array(
										'size-default' => __( 'Default', 'differ_kc' ),
										'size-big'     => __( 'Big', 'differ_kc' ),
										'size-small'   => __( 'Small', 'differ_kc' ),
									),
									'value'   => 'default',
								),
								array(
									'name'    => 'btn_color',
									'label'   => __( 'Button Color', 'differ_kc' ),
									'type'    => 'select',
									'options' => array(
										'black'   => __( 'Black', 'differ_kc' ),
										'white'   => __( 'White', 'differ_kc' ),
										'primary' => __( 'Primary Color', 'differ_kc' ),
									),
									'value'   => 'black',
								),
								array(
									'name'    => 'btn_hover_color',
									'label'   => __( 'Button Hover Color', 'differ_kc' ),
									'type'    => 'select',
									'options' => array(
										'hover-black'   => __( 'Black', 'differ_kc' ),
										'hover-white'   => __( 'White', 'differ_kc' ),
										'hover-primary' => __( 'Primary Color', 'differ_kc' ),
									),
									'value'   => 'black',
								),
								array(
									'name'    => 'btn_style',
									'label'   => __( 'Button Style', 'differ_kc' ),
									'type'    => 'select',
									'options' => array(
										'style-primary'      => __( 'Primary', 'differ_kc' ),
										'style-primary-fill' => __( 'Primary Fill', 'differ_kc' ),
										'style-black'        => __( 'Black', 'differ_kc' ),
										'style-black-fill'   => __( 'Black Fill', 'differ_kc' ),
										'style-white'        => __( 'White', 'differ_kc' ),
										'style-white-fill'   => __( 'White Fill', 'differ_kc' ),
									),
									'value'   => 'black',
								),
								array(
									'name'    => 'btn_radius',
									'label'   => __( 'Button Radius', 'differ_kc' ),
									'type'    => 'select',
									'options' => array(
										'rect'    => __( 'Rectangle', 'differ_kc' ),
										'rounded' => __( 'Rounded', 'differ_kc' ),
									),
									'value'   => 'default',
								),
								array(
									'name'  => 'btn_link',
									'label' => __( 'Button Link', 'differ_kc' ),
									'type'  => 'link',
								)
							)
						)
					),
					'styles'  => array(
						array(
							'name'  => 'differ_buttons_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)

				)
			)
		)
	);


}
