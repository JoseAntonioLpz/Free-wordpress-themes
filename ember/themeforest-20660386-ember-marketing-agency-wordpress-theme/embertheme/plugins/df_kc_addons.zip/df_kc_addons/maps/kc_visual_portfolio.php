<?php

$vp_query = get_posts(
	array(
		'post_type'      => 'vp_lists',
		'posts_per_page' => - 1,
		'showposts'      => - 1,
		'paged'          => - 1,
	)
);
$data_vc  = array();
foreach ( $vp_query as $post ) {
	$data_vc[ $post->ID ] = $post->post_title;
}


if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_visual_portfolio' => array(
				'name'        => __( 'Visual Portfolio', 'differ_kc' ),
				'title'       => __( 'Visual Portfolio', 'differ_kc' ),
				'description' => __( 'Visual Portfolio', 'differ_kc' ),
				'icon'        => 'ember-visual-portfolio',
				'category'    => 'Ember',
				'css_box'     => true,
				'params'      => array(
					'general' => array(
						array(
							'name'    => 'vp_id',
							'label'   => __( 'Select Portfolio Layout', 'differ_kc' ),
							'type'    => 'select',
							'options' => $data_vc
						),
					),
					'styles'  => array(
						array(
							'name'  => 'differ_buttons_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)
				)
			)
		)
	);
}
