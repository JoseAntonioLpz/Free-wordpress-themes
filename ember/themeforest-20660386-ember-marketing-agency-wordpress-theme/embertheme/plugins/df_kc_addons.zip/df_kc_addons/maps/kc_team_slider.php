<?php


if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_team_slider' => array(
				'name'        => __( 'Team Slider', 'differ_kc' ),
				'title'       => __( 'Team Slider', 'differ_kc' ),
				'description' => __( 'Team Slider', 'differ_kc' ),
				'icon'        => 'ember-team-slider',
				'category'    => 'Ember',
				'css_box'     => true,
				'params'      => array(
					'general'  => array(


						array(
							'type'    => 'group',
							'label'   => __( 'Team', 'differ_kc' ),
							'name'    => 'team',
							'options' => array( 'add_text' => __( 'Add new member', 'differ_kc' ) ),

							'params' => array(

								array(
									'type'        => 'text',
									'label'       => __( 'Name', 'differ_kc' ),
									'name'        => 'name',
									'admin_label' => true,
								),
								array(
									'type'        => 'text',
									'label'       => __( 'Position', 'differ_kc' ),
									'name'        => 'position',
									'admin_label' => true,
								),
								array(
									'name'        => 'photo',
									'label'       => __( 'Photo', 'differ_kc' ),
									'type'        => 'attach_image',  // USAGE ATTACH_IMAGE TYPE
									'description' => __( 'Recommended size 370x400', 'differ_kc' )
								),
								array(
									'type'        => 'text',
									'label'       => '<i class="fas fa-envelope"></i> ' . __( 'Email', 'differ_kc' ),
									'name'        => 'email',
									'admin_label' => true,
								),
								array(
									'type'        => 'text',
									'label'       => '<i class="fab fa-facebook-f"></i> ' . __( 'Facebook', 'differ_kc' ),
									'name'        => 'facebook',
									'admin_label' => true,
								),
								array(
									'type'        => 'text',
									'label'       => '<i class="fab fa-twitter"></i> ' . __( 'Twitter', 'differ_kc' ),
									'name'        => 'twitter',
									'admin_label' => true,
								),
								array(
									'type'        => 'text',
									'label'       => '<i class="fab fa-instagram"></i> ' . __( 'Instagram', 'differ_kc' ),
									'name'        => 'instagram',
									'admin_label' => true,
								),
								array(
									'type'        => 'text',
									'label'       => '<i class="fab fa-vk"></i> ' . __( 'Vk', 'differ_kc' ),
									'name'        => 'vk',
									'admin_label' => true,
								),
								array(
									'type'        => 'text',
									'label'       => '<i class="fab fa-behance"></i> ' . __( 'Behance', 'differ_kc' ),
									'name'        => 'behance',
									'admin_label' => true,
								),
								array(
									'type'        => 'text',
									'label'       => '<i class="fab fa-dribbble"></i> ' . __( 'Dribble', 'differ_kc' ),
									'name'        => 'dribble',
									'admin_label' => true,
								),


							)
						)


					),
					'settings' => array(
						array(
							'name'        => 'slide_speed',
							'label'       => __( 'Slide Speed', 'differ_kc' ),
							'type'        => 'number_slider',  // USAGE RADIO TYPE
							'options'     => array(    // REQUIRED
								'min'        => 100,
								'max'        => 1000,
								'show_input' => true
							),
							'value'       => '300',
							'description' => __( 'Duration of transition between slides (in ms)', 'differ_kc' ),
						),
						array(
							'name'        => 'grab_cursor',
							'label'       => __( 'Grab Cursor', 'differ_kc' ),
							'type'        => 'toggle',
							'value'       => 'no',
							'description' => __( 'This option may a little improve desktop usability. If true, user will see the "grab" cursor when hover on Swiper', 'differ_kc' ),
						),
						array(
							'name'        => 'loop',
							'label'       => __( 'Loop', 'differ_kc' ),
							'type'        => 'toggle',
							'value'       => 'yes',
							'description' => __( 'Set to true to enable continuous loop mode', 'differ_kc' ),
						),
						array(
							'name'  => 'autoplay',
							'label' => __( 'Autoplay', 'differ_kc' ),
							'type'  => 'toggle',
							'value' => 'yes',
						),
						array(
							'name'        => 'delay',
							'label'       => __( 'Autoplay Delay', 'differ_kc' ),
							'type'        => 'number_slider',  // USAGE RADIO TYPE
							'options'     => array(    // REQUIRED
								'min'        => 500,
								'max'        => 15000,
								'show_input' => true
							),
							'value'       => '3000',
							'description' => __( 'Duration of transition between slides (in ms)', 'differ_kc' ),
							'relation'    => array(
								'parent'    => 'autoplay',
								'show_when' => 'yes'
							)
						),
						array(
							'name'  => 'arrows',
							'label' => __( 'Arrows', 'differ_kc' ),
							'type'  => 'toggle',
							'value' => 'yes',
						),
					),
					'styles'   => array(
						array(
							'name'  => 'image_section_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)
				)
			)
		)
	);


}
