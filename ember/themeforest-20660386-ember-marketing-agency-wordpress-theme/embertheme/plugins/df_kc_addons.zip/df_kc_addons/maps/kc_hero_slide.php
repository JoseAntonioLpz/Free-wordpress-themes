<?php


if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_hero_slide' => array(
				'name'        => esc_attr( 'Hero Slide', 'textdomain' ),
				'title'       => esc_attr( 'Hero Slide', 'textdomain' ),
				'category'    => 'Ember',
				'css_box'     => true,
				'system_only' => true,
				'nested'      => true,
				'params'      => array(
					'styles' => array(
						array(
							'name'    => 'differ_hero_slide_css',
							'label'   => __( 'Styles', 'differ_kc' ),
							'type'    => 'css',
							'options' => array(
								array(
									'screens' => "any",

									'Background' => array(
										array( 'property' => 'background' ),
									),

								),
								array(
									"screens" => "999,768,667,479",


									'Background' => array(
										array( 'property' => 'background' ),
									),


								)
							)
						)
					)
				)
			),
		)
	);


}

