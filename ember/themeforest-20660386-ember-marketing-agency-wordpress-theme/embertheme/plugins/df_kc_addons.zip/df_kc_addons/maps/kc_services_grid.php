<?php


if ( function_exists( 'kc_add_map' ) ) {
	kc_add_map(
		array(
			'kc_services_grid' => array(
				'name'        => __( 'Services Grid', 'differ_kc' ),
				'title'       => __( 'Services Grid', 'differ_kc' ),
								'description' => __( 'Services Grid', 'differ_kc' ),
				'icon'        => 'ember-services-grid',
				'category'    => 'Ember',
				'css_box'     => true,
				'params'      => array(
					'general' => array(
						array(
							'type'        => 'group',
							'label'       => __( 'Services', 'differ_kc' ),
							'name'        => 'services',
							'description' => '',
							'options'     => array( 'add_text' => __( 'Add Service', 'differ_kc' ) ),
							'params'      => array(
								array(
									'name'  => 'service_title',
									'label' => __( 'Title', 'differ_kc' ),
									'type'  => 'text',
								),
								array(
									'name'  => 'service_icon',
									'label' => __( 'Service Icon', 'differ_kc' ),
									'type'  => 'icon_picker',
								),
								array(
									'name'        => 'service_content',
									'label'       => __( 'Content', 'differ_kc' ),
									'type'        => 'textarea',
									'description' => esc_attr__( 'Not more than one sentence', 'differ_kc' )
								),
								array(
									'name'  => 'service_permalink_enbale',
									'label' => __( 'Enable Link Button', 'differ_kc' ),
									'type'  => 'toggle',
									'value' => 'yes'
								),
								array(
									'name'     => 'service_permalink',
									'label'    => __( 'Permalink Button', 'differ_kc' ),
									'type'     => 'link',
									'relation' => array(
										'parent'    => 'services-service_permalink_enbale',
										'show_when' => 'yes'
									),
								)
							)
						)
					),
					'styles'  => array(
						array(
							'name'  => 'differ_buttons_css',
							'label' => __( 'Styles', 'differ_kc' ),
							'type'  => 'css',
						)
					)
				)
			)
		)
	);


}
