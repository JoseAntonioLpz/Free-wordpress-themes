<?php


$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;
ob_start(); ?>

<div class="<?php echo implode( ' ', $el_classes ); ?> kc_services_grid">
    <div class="section-flex">
		<?php foreach ( $atts['services'] as $item ): ?>
            <div class="item">
                <div class="wrap">
                    <div class="up">
						<?php if ( $item->service_icon && ! empty( $item->service_icon ) ): ?>
                            <i class="icon <?php echo esc_attr( $item->service_icon ); ?>"></i>
						<?php endif; ?>
						<?php if ( $item->service_title && ! empty( $item->service_title ) ): ?>
                            <h6 class="title white"><?php echo esc_attr( $item->service_title ); ?></h6>
						<?php endif; ?>
                    </div>
                    <div class="down">
						<?php if ( $item->service_title && ! empty( $item->service_title ) ): ?>
                            <h6 class="title white"><?php echo esc_attr( $item->service_title ); ?></h6>
						<?php endif; ?>
						<?php if ( $item->service_content && ! empty( $item->service_content ) ): ?>
                            <p>
								<?php echo esc_attr( $item->service_content ); ?>
                            </p>
						<?php endif; ?>

						<?php if ( $item->service_permalink_enbale == 'yes' ):
							$link = explode( '|', $item->service_permalink );

							if ( ! isset( $link[0] ) ) {
								$link[0] = '#';
							}
							if ( ! isset( $link[1] ) ) {
								$link[1] = esc_attr__( 'Read More', 'embertheme' );
							}
							if ( ! isset( $link[2] ) ) {
								$link[2] = '_self';
							}

							?>
                            <a target="<?php echo esc_attr( $link[2] ); ?>" href="<?php echo esc_url( $link[0] ); ?>" class="permalink-btn btn size-small rounded white hover-white style-primary"><?php echo esc_attr( $link[1] ); ?></a>
						<?php endif; ?>
                    </div>
                </div>
            </div>
		<?php endforeach; ?>
    </div>
</div>

