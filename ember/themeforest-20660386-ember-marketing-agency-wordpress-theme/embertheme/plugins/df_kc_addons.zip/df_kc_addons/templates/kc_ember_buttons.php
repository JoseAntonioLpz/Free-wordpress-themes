<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;
$el_classes[] = $atts['alignment'];
?>


<div class="<?php echo implode( ' ', $el_classes ); ?> kc_ember_buttons">

	<?php foreach ( $atts['buttons'] as $item ) {
		$el_classes   = array( 'btn', 'kc_ember_button' );
		$el_classes[] = $item->btn_radius;
		$el_classes[] = $item->btn_hover_color;
		$el_classes[] = $item->btn_color;
		$el_classes[] = $item->btn_size;
		$el_classes[] = $item->btn_style;
		$link         = explode( '|', $item->btn_link );

		if ( ! isset( $link[0] ) ) {
			$link[0] = '#';
		}
		if ( ! isset( $link[1] ) ) {
			$link[1] = 'Button';
		}
		if ( ! isset( $link[2] ) ) {
			$link[2] = '_self';
		}
		?>

        <a href="<?php echo esc_url( $link[0] ); ?>" target="<?php echo esc_attr( $link[2] ); ?>" class="<?php echo implode( ' ', $el_classes ); ?>">
			<?php echo esc_attr( $link[1] ); ?>
        </a>

	<?php } ?>

</div>
