<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;

?>


<div class="<?php echo implode( ' ', $el_classes ); ?> kc_youtube_video ">

	<?php
	// Youtube Video ID
	parse_str( parse_url( $atts['link'], PHP_URL_QUERY ), $id );
	$video_id = $id['v'];

	// Video Start Time
	sscanf( $atts['start'], "%d:%d:%d", $hours, $minutes, $seconds );
	$start = $time_seconds = isset( $seconds ) ? $hours * 3600 + $minutes * 60 + $seconds : $hours * 60 + $minutes;


	$url_arr = array();

	if ( $atts['privacy'] !== 'yes' ) {
		$url_arr[] = "https://www.youtube.com/embed/{$video_id}/?";
	} else {
		$url_arr[] = "https://www.youtube-nocookie.com/embed/{$video_id}/?";
	}
	if ( $atts['similar_videos'] !== 'yes' ) {
		$url_arr[] = "rel=0&amp;";
	}
	if ( $atts['control'] !== 'yes' ) {
		$url_arr[] = "controls=0&amp;";
	}
	if ( $atts['title_action_bar'] !== 'yes' ) {
		$url_arr[] = "showinfo=0&amp;";
	}
	if ( $atts['start'] !== '0:00' && $atts['start'] !== '' && ! empty( $atts['start'] ) ) {
		$url_arr[] = "start={$start};";
	}
	$video_url = implode( '', $url_arr );

	?>

    <div class="iframe-wrap">
        <iframe src="<?php echo $video_url; ?>" allowfullscreen></iframe>
    </div>

</div>


