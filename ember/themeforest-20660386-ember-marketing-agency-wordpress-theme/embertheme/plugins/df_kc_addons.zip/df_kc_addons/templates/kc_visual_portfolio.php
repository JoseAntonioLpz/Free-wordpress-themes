<?php

$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;
ob_start(); ?>

<div class="<?php echo implode( ' ', $el_classes ); ?> kc_visual_portfolio">
	<?php

	if ( class_exists( 'Visual_Portfolio_Get' ) ) {
		echo Visual_Portfolio_Get::get( array( 'id' => $atts['vp_id'] ) );
	}

	?>
</div>

