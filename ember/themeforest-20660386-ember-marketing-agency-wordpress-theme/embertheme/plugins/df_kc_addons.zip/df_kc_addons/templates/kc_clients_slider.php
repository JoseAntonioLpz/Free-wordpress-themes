<?php
$el_classes = apply_filters( 'kc-el-class', $atts );

! empty( $extra_class ) ? $el_classes[] = $extra_class : null;
ob_start();


/* Swiper Slider */
wp_enqueue_style( 'differ-swiper-css' );
wp_enqueue_script( 'differ-swiper-js' );


?>




<div class="<?php echo implode( ' ', $el_classes ); ?> kc_clients_slider  ">
    <h6 class="hidden none empty">&nbsp;</h6>

    <div class="swiper-container clients-slider">
        <div class="swiper-wrapper">
			<?php
			foreach ( $atts['logos'] as $item ):
				if ( ! empty( $item->link ) ): ?>
                    <a target="_blank" href="<?php echo esc_url( $item->link ); ?>" class="swiper-slide ">
                        <img src="<?php echo esc_url( wp_get_attachment_image_url( $item->image, array( 250, 250 ) ) ); ?>" alt="<?php echo esc_attr( $item->title ); ?>">
                    </a>
				<?php else: ?>
                    <div class="swiper-slide ">
                        <img src="<?php echo esc_url( wp_get_attachment_image_url( $item->image, array( 250, 250 ) ) ); ?>" alt="<?php echo esc_attr( $item->title ); ?>">
                    </div>
				<?php endif;
			endforeach;
			?>
        </div>
    </div>
</div>


<style>
        .kc-css-<?php echo $atts['_id']; ?> .clients-slider .swiper-slide {
            width: calc(100% / <?php echo $atts['xl_cols'];   ?>);
        }

        .kc-css-<?php echo $atts['_id']; ?> .clients-slider .swiper-slide img {

            max-height: <?php echo $atts['img_height']; ?>;
        }

        @media (max-width: 1200px) {
            .kc-css-<?php echo $atts['_id']; ?> .clients-slider .swiper-slide {
                width: calc(100% / <?php echo $atts['lg_cols'];   ?>);
            }
        }

        @media (max-width: 991px) {
            .kc-css-<?php echo $atts['_id']; ?> .clients-slider .swiper-slide {
                width: calc(100% / <?php echo $atts['md_cols'];   ?>);
            }
        }

        @media (max-width: 768px) {
            .kc-css-<?php echo $atts['_id']; ?> .clients-slider .swiper-slide {
                width: calc(100% / <?php echo $atts['sm_cols'];   ?>);
            }
        }

        @media (max-width: 560px) {
            .kc-css-<?php echo $atts['_id']; ?> .clients-slider .swiper-slide {
                width: calc(100% / <?php echo $atts['xs_cols'];   ?>);
            }
        }
    </style>

