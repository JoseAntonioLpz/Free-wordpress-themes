<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;

?>

<div class="<?php echo implode( ' ', $el_classes ); ?> kc_image_section">
    <div class="row">
        <div class="col-lg-6 image-wrap">
            <img src="<?php echo esc_url( wp_get_attachment_image_url( $atts['image'], array( 250, 250 ) ) ); ?>" class="img-responsive" alt="">
        </div>
        <div class="col-lg-6 text-block">
			<?php echo $atts['text']; ?>
        </div>
    </div>
</div>