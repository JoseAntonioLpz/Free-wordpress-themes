<?php


$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;
ob_start();


wp_enqueue_style( 'differ-swiper-css' );
wp_enqueue_script( 'differ-swiper-js' );


?>

<div class="<?php echo implode( ' ', $el_classes ); ?> kc_team_slider">

        <div class="swiper-container"
             data-speed="<?php echo $atts['slide_speed']; ?>"
             data-grab="<?php echo $atts['grab_cursor']; ?>"
             data-autoplay="<?php echo $atts['autoplay']; ?>"
             data-delay="<?php echo $atts['delay']; ?>"
             data-count="<?php echo count( $atts['team'] ); ?>"
             data-loop="<?php echo $atts['loop']; ?>"
        >

            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">

                <!-- Slides -->
				<?php foreach ( $atts['team'] as $slide ): ?>
                    <div class="swiper-slide">
                        <div class="member">
                            <div class="photo"><img src="<?php echo esc_url( wp_get_attachment_image_url( $slide->photo, array( 370, 400 ) ) ); ?>" alt=""></div>
                            <div class="description">
                                <div class="member-info">
                                    <p class="name"><?php echo $slide->name; ?></p>
                                    <p class="position"><?php echo $slide->position; ?></p>
                                </div>
                                <div class="social">
									<?php if ( ! empty( $slide->facebook ) ): ?>
                                        <a target="_blank" href="<?php $slide->facebook; ?>"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
									<?php endif; ?>
									<?php if ( ! empty( $slide->email ) ): ?>
                                        <a target="_blank" href="mailto:<?php $slide->email; ?>"><i class="fas fa-envelope"></i></a>
									<?php endif; ?>
									<?php if ( ! empty( $slide->twitter ) ): ?>
                                        <a target="_blank" href="<?php $slide->twitter; ?>"><i class="fab fa-twitter"></i></a>
									<?php endif; ?>
									<?php if ( ! empty( $slide->vk ) ): ?>
                                        <a target="_blank" href="<?php $slide->vk; ?>"><i class="fab fa-vk"></i></a>
									<?php endif; ?>
									<?php if ( ! empty( $slide->behance ) ): ?>
                                        <a target="_blank" href="<?php $slide->behance; ?>"><i class="fab fa-behance"></i></a>
									<?php endif; ?>
									<?php if ( ! empty( $slide->dribble ) ): ?>
                                        <a target="_blank" href="<?php $slide->dribble; ?>"><i class="fab fa-dribbble"></i></a>
									<?php endif; ?>
                                </div>
                            </div>
                        </div>


                    </div>
				<?php endforeach; ?>
            </div>

	        <?php if ( $atts['arrows'] == 'yes' ): ?>
                <!-- Button -->
                <div class="button-prev"><i class="sl-arrow-left" aria-hidden="true"></i></div>
                <div class="button-next"><i class="sl-arrow-right" aria-hidden="true"></i></div>
	        <?php endif; ?>
        </div>




</div>

