<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;


$api_key = ! empty( $atts['api_key'] ) ? $atts['api_key'] : differ_get_option( 'google_api_key' );

if ( differ_get_option( 'google_api_key' ) ) {
	wp_enqueue_script( 'differ-google-api-key', 'https://maps.googleapis.com/maps/api/js?key=' . $api_key, false, null, true );
}


?>


<div class="<?php echo implode( ' ', $el_classes ); ?> kc_google_map ">


    <div class=" map-section">
        <div class="info hidden">
            <div class="zoom"><?php echo $atts['zoom']; ?></div>
            <div class="map_latitude"><?php echo $atts['latitude']; ?></div>
            <div class="map_longitude"><?php echo $atts['longitude']; ?></div>
            <div class="map_style"><?php echo $atts['style']; ?></div>
            <div class="map_pin_icon"><?php echo esc_url( wp_get_attachment_image_url( $atts['map_pin_icon'], array( 80, 80 ) ) ); ?></div>

			<?php $i = 0;
			foreach ( $atts['markers'] as $item ): $i ++; ?>
                <div data-marker="<?php echo esc_attr( $i ); ?>" class="marker marker<?php echo esc_attr( $i ); ?>">
                    <div data-marker="<?php echo esc_attr( $i ); ?>" class="latitude<?php echo esc_attr( $i ); ?>"><?php echo $item->latitude; ?></div>
                    <div data-marker="<?php echo esc_attr( $i ); ?>" class="longitude<?php echo esc_attr( $i ); ?>"><?php echo $item->longitude; ?></div>
                    <div data-marker="<?php echo esc_attr( $i ); ?>" class="tooltip<?php echo esc_attr( $i ); ?>"><?php echo $item->content; ?></div>
                </div>
			<?php endforeach; ?>
        </div>

        <div class="map <?php $atts['map_width'] == 'yes' ? print 'full' : print 'boxed'; ?> " style="height: <?php echo $atts['map_height'] . 'px'; ?>">
        </div>
    </div>


</div>


