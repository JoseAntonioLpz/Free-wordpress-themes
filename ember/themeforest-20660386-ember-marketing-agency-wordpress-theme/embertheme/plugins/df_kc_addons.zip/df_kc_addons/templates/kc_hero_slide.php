<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;

$el_classes[] = 'kc_hero_slide';
$el_classes[] = 'swiper-slide';

?>

<div class="<?php echo implode( ' ', $el_classes ); ?>   kc_hero_slide">
    <div class="container no-padding">
		<?php echo do_shortcode( str_replace( 'kc_hero_slide#', 'kc_hero_slide', $content ) ); ?>
    </div>
</div>


