<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;
ob_start();

wp_enqueue_style( 'differ-swiper-css' );
wp_enqueue_script( 'differ-swiper-js' );

$id = $atts['_id'];

?>

<div class="<?php echo implode( ' ', $el_classes ); ?> kc_hero_slider">
    <div class="swiper-container  hero-slide-<?php echo $id; ?>">

        <div class="swiper-wrapper">
			<?php echo do_shortcode( str_replace( 'kc_hero_slider#', 'kc_hero_slider', $content ) ); ?>
        </div>

		<?php if ( $atts['pagination'] ): ?>
            <div class="swiper-pagination swiper-pagination-<?php echo $id; ?>"></div>
		<?php endif; ?>

		<?php if ( $atts['arrows'] ): ?>
            <div class="button-prev prev-<?php echo $id; ?>"><i class="sl-arrow-left" aria-hidden="true"></i></div>
            <div class="button-next next-<?php echo $id; ?>"><i class="sl-arrow-right" aria-hidden="true"></i></div>
		<?php endif; ?>
    </div>
</div>


<script>
    jQuery(document).ready(($) => {
        let slider = $('.kc_hero_slider .swiper-container');
        if (slider.length) {
            let mySwiper = new Swiper('.hero-slide-<?php echo $id; ?>', {
                direction: 'horizontal',

				<?php if($atts["loop"]): ?>
                loop: true,
				<?php endif; ?>

                slidesPerView: 1,
                effect: '<?php echo $atts["efect"]; ?>',
                speed: <?php echo $atts['slide_speed']; ?>,

				<?php if ($atts["grab_cursor"]): ?>
                grabCursor: true,
				<?php endif; ?>

				<?php if ( $atts['pagination'] ): ?>
                pagination: {
                    el: '.swiper-pagination-<?php echo $id; ?>',
                    type: 'bullets',
                    clickable: true
                },
				<?php endif; ?>

				<?php if ( $atts['arrows'] ): ?>
                navigation: {
                    nextEl: '.prev-<?php echo $id; ?>',
                    prevEl: '.next-<?php echo $id; ?>',
                },
				<?php endif; ?>

            });
        }
    });
</script>