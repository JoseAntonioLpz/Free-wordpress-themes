<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;


?>


<div class="<?php echo implode( ' ', $el_classes ); ?> kc_contact_links ">


    <div class="items">
		<?php foreach ( $atts['links'] as $item ) : ?>


			<?php $link = explode( '|', $item->link );

			if ( ! isset( $link[0] ) ) {
				$link[0] = '#';
			}
			if ( ! isset( $link[1] ) ) {
				$link[1] = esc_attr__( '', 'differ_kc' );
			}
			if ( ! isset( $link[2] ) ) {
				$link[2] = '_self';
			}

			if ( empty( $link[0] ) || $link[0] == '' ): ?>
                <div class="item"><i class="icon <?php echo $item->icon; ?>" aria-hidden="true"></i> <span><?php echo $link[1]; ?></span></div>
			<?php else: ?>
                <a target="<?php echo $link[2]; ?>" href="<?php echo $link[0] ?>" class="item"><i class="icon <?php echo $item->icon; ?>" aria-hidden="true"></i> <span><?php echo $link[1]; ?></span></a>
			<?php endif; ?>


		<?php endforeach; ?>
    </div>


</div>


