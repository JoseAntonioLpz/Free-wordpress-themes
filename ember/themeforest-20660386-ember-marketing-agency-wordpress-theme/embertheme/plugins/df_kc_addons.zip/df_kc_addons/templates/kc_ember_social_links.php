<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;


?>


<div class="<?php echo implode( ' ', $el_classes ); ?> kc_social_links ">


    <div class="items">
		<?php foreach ( $atts['links'] as $item ) : ?>


			<?php $link = explode( '|', $item->link );

			if ( ! isset( $link[0] ) ) {
				$link[0] = '#';
			}
			if ( ! isset( $link[1] ) ) {
				$link[1] = esc_attr__( '', 'differ_kc' );
			}
			if ( ! isset( $link[2] ) ) {
				$link[2] = '_self';
			}

			?>

            <a target="<?php echo $link[2]; ?>" class="bar" href="<?php echo $link[0]; ?>">
                <span class="icon <?php echo $item->icon; ?>" aria-hidden="true"></span>
            </a>


		<?php endforeach; ?>
    </div>


</div>


