<?php

$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;
$image = wp_get_attachment_image_url( $atts['bg_image'], array( 1400, 600 ) );
$atts['parallax'] == 'yes' ? $el_classes[] = 'parallax' : null;
$title = $atts['title'];

$btn_classes   = array( 'btn', 'kc_ember_button' );
$btn_classes[] = $atts['btn_radius'];
$btn_classes[] = $atts['btn_hover_color'];
$btn_classes[] = $atts['btn_color'];
$btn_classes[] = $atts['btn_size'];
$btn_classes[] = $atts['btn_style'];
$link          = explode( '|', $atts['btn_link'] );

if ( ! isset( $link[0] ) ) {
	$link[0] = '#';
}
if ( ! isset( $link[1] ) ) {
	$link[1] = 'Button';
}
if ( ! isset( $link[2] ) || ! empty( $link[2] ) ) {
	$link[2] = '_self';
}
?>


<div class="<?php echo implode( ' ', $el_classes ); ?> kc_call_to_action  " style="background-image: url(<?php echo esc_url( $image ); ?>)">

    <div class="container">
        <div class="flex">
            <h3 class="title"><?php echo esc_attr( $title ); ?></h3>
            <a href="<?php echo esc_url( $link[0] ); ?>"
			   <?php if ( isset( $link[2] ) || ! empty( $link[2] ) ): ?>target="<?php echo esc_attr( $link[2] );
			   endif; ?>"
               class="<?php echo implode( ' ', $btn_classes ); ?>">
				<?php echo esc_attr( $link[1] ); ?>
            </a>
        </div>
    </div>
</div>