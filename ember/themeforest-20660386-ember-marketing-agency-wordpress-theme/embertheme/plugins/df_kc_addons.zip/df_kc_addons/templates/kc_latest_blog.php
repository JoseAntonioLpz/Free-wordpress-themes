<?php
$el_classes = apply_filters( 'kc-el-class', $atts );
! empty( $extra_class ) ? $el_classes[] = $extra_class : null;

$sticky      = get_option( 'sticky_posts' );
$posts_count = $atts['posts_count'];


if ( $atts['select_enable'] == 'yes' ) {
	$posts_count = - 1;
}


$args = array(
	'posts_per_page'      => $posts_count,
	'post_type'           => 'post',
	'ignore_sticky_posts' => 1,
	'post__not_in'        => $sticky,
);


if ( $atts['select_enable'] == 'yes' ) {
	$args['post__in'] = explode( ',', $atts['posts'] );
}

$posts = new WP_Query( $args );

if ( $atts['cols_count'] == '2' ):
	$post_class = 'col-lg-6 col-sm-12';
elseif ( $atts['cols_count'] == '3' ):
	$post_class = 'col-lg-4 col-md-6 col-sm-12';
elseif ( $atts['cols_count'] == '4' ):
	$post_class = 'col-xl-3 col-lg-4 col-md-6 col-sm-12';
endif;

?>

<div class="<?php echo implode( ' ', $el_classes ); ?> kc_latest_blog  ">
    <div class="row">
		<?php
		if ( $posts->have_posts() ): while ( $posts->have_posts() ): $posts->the_post();
			if ( has_post_thumbnail() ): ?>

                <article class="post <?php echo esc_attr( $post_class ); ?>">
                    <div class="post-body">
                        <a href="<?php the_permalink(); ?>" class="post-head">
                            <div class="thumbnail-wrap" style="max-height:<?php echo esc_attr( $atts['img_height'] ) ?>px">
                                <img src="<?php the_post_thumbnail_url( 'differ_post_blogimg' ) ?>" alt="<?php the_title(); ?>" style="min-height:<?php echo esc_attr( $atts['img_height'] ) ?>px">
                                <div class="actions">
                                    <div class="date">
                                        <i class="fa fa-calendar"
                                           aria-hidden="true"></i>
                                        <span><?php echo esc_attr( get_the_date() ); ?></span>
                                    </div>
                                    <div class="comments">
                                        <i class="fa fa-comments"
                                           aria-hidden="true"></i>
                                        <span><?php comments_number( '0' ); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="hover">
                                <i class="fa fa-search" aria-hidden="true"></i>
                            </div>
                        </a>
                        <div class="other-post">
                            <a class="post-title" href="<?php the_permalink(); ?>">
                                <h6><?php echo esc_attr( wp_trim_words( get_the_title(), $atts['title_crop'] ) ); ?></h6>
                            </a>
                            <p><?php echo esc_attr( wp_trim_words( get_the_excerpt(), $atts['excerpt_crop'] ) ); ?></p>
                            <a href="<?php the_permalink(); ?>" class="btn kc_ember_button rect hover-white black size-small style-primary">
								<?php esc_html_e( 'Read More', 'embertheme' ); ?>
                            </a>
                        </div>
                    </div>
                </article>

			<?php endif; endwhile; endif;
		wp_reset_query(); ?>
    </div>
</div>