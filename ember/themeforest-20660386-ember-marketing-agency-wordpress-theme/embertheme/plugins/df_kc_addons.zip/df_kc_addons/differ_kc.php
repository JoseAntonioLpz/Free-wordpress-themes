<?php
/*
Plugin Name: DifferThemes KC Addons
Plugin URI: https://themeforest.net/user/differthemes?rel=DifferThemes
Description: Addons for KingComposer by DifferThemes
Author: DifferThemes
Version: 1.0
License:      GPLv2 or later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  differ_kc
*/


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

load_plugin_textdomain( 'differ_kc', false, basename( dirname( __FILE__ ) ) . '/lang' );


add_action( 'init', 'kc_addons_init', 99 );

function kc_addons_init() {
	if ( function_exists( 'kc_add_map' ) ) {


		global $kc;
		$plugin_template = plugin_dir_path( __FILE__ ) . 'templates/';
		$plugin_maps     = plugin_dir_path( __FILE__ ) . 'maps/';
		$kc->set_template_path( $plugin_template );


		/* Call to Action */
		require_once( $plugin_maps . 'kc_call_to_action.php' );
		require_once( $plugin_maps . 'kc_clients_slider.php' );
		require_once( $plugin_maps . 'kc_ember_buttons.php' );
		require_once( $plugin_maps . 'kc_latest_blog.php' );
		require_once( $plugin_maps . 'kc_services_grid.php' );
		require_once( $plugin_maps . 'kc_visual_portfolio.php' );
		require_once( $plugin_maps . 'kc_image_section.php' );
		require_once( $plugin_maps . 'kc_team_slider.php' );
		require_once( $plugin_maps . 'kc_youtube_video.php' );
		require_once( $plugin_maps . 'kc_differ_google_map.php' );
		require_once( $plugin_maps . 'kc_differ_contact_form7.php' );
		require_once( $plugin_maps . 'kc_contact_links.php' );
		require_once( $plugin_maps . 'kc_ember_social_links.php' );


		require_once( $plugin_maps . 'kc_hero_slider.php' );
		require_once( $plugin_maps . 'kc_hero_slide.php' );


		/* kc_nested */
		$kc->add_map_param(
			'kc_nested',
			array(
				'css_box' => true,
			),
			1 );

		$kc->update_map(
			'kc_nested',
			'params',
			array(
				array(
					'name'  => 'differ_buttons_css',
					'label' => __( 'Styles', 'differ_kc' ),
					'type'  => 'css',
				)
			)
		);
		$kc->remove_map_param( 'kc_contact_form7', 'title' );

	}

}


