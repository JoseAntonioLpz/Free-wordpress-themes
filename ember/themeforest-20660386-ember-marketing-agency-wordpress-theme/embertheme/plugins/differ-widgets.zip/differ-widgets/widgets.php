<?php
/*
Plugin Name: DifferThemes Widgets
Plugin URI: https://themeforest.net/user/differthemes?rel=DifferThemes
Description: Widgets for Wordpress
Author: DifferThemes
Version: 1.0
License:      GPLv2 or later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  differ_widgets
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

load_plugin_textdomain( 'differ_widgets', false, basename( dirname( __FILE__ ) ) . '/lang' );

define( 'WIDGETS_PATH', plugin_dir_path( __FILE__ ) . 'widgets' );

require_once( WIDGETS_PATH . '/flickr-widget.php' );
require_once( WIDGETS_PATH . '/instagram-widget.php' );
require_once( WIDGETS_PATH . '/recent-posts-widget.php' );