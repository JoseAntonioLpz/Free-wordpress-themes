<?php


class Differ_Latest_Posts_Widget extends WP_Widget {

// Main constructor
	public function __construct() {

		$widget_id       = 'differ_latest_posts';
		$widget_title    = __( 'Latest Posts', 'differ_widgets' );
		$widget_settings = array(
			'customize_selective_refresh' => true,
			'classname'                   => 'differ_latest_posts_widget',
			'description'                 => esc_html__( 'Display Latest Posts with thumbnails', 'differ_widgets' )
		);

		parent::__construct( $widget_id, $widget_title, $widget_settings );
	}

// The widget form (for the backend )
	public function form( $instance ) {

// Set widget defaults
		$defaults = array(
			'title' => esc_html__( 'Latest Posts', 'differ_widgets' ),
			'count' => '3',
		);
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<!-- Title -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Widget Title', 'differ_widgets' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>"/>
		</p>

		<!-- Posts Count -->
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"><?php _e( 'Posts Count:', 'differ_widgets' ); ?></label>
			<input type="number" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>" value="<?php echo esc_attr( $instance['count'] ); ?>"/>
		</p>



		<?php
	}

// Update widget settings
	public function update( $new_instance, $old_instance ) {
		$instance          = $old_instance;
		$instance['title'] = isset( $new_instance['title'] ) ? wp_strip_all_tags( $new_instance['title'] ) : '';
		$instance['count'] = isset( $new_instance['count'] ) ? wp_strip_all_tags( $new_instance['count'] ) : '';

		return $instance;
	}

// Display the widget
	public function widget( $args, $instance ) {

		extract( $args );
		// Check the widget options
		$title = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : 'Instagram Feed';
		$count = isset( $instance['count'] ) ? $instance['count'] : '3';

		echo $before_widget;

		if ( $title ) :
			echo ( $before_title ) . esc_attr( $title ) . ( $after_title );
		endif; ?>


		<div class="widget-recent-posts">
			<ul class="posts">

				<?php

				$sticky = get_option( 'sticky_posts' );
				$query  = new WP_Query( array(
					'posts_per_page'      => $count,
					'ignore_sticky_posts' => 1,
					'post__not_in'        => $sticky,
				) );
				?>
				<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); ?>
					<li>
						<?php if ( has_post_thumbnail() ) { ?>
							<a href="<?php the_permalink(); ?>"><img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" class="widget-posts-img"></a> <?php } ?>
						<div class="widget-posts-descr">
							<a href="<?php the_permalink(); ?>" class="title"><?php echo wp_trim_words( get_the_title(), 6 ); ?></a>
							<div class="date"><?php echo esc_attr( get_the_date() ); ?></div>
						</div>
					</li>
				<?php endwhile; endif; ?>


			</ul>

		</div>


		<?php echo $after_widget;
	}
}


// Register Widget
function differ_register_latest_posts_widget() {
	register_widget( 'Differ_Latest_Posts_Widget' );
}

add_action( 'widgets_init', 'differ_register_latest_posts_widget' );