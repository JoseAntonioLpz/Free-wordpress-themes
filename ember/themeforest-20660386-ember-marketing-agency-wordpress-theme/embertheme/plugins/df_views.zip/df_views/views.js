jQuery(document).ready(($) => {
    "use strict";


    function views() {

        if (differLikes.id !== '') {

            $.ajax({
                type: 'POST',
                url: differLikes.ajax_url,
                data: {
                    action: 'differ_views',
                    nonce: differLikes.nonce,
                    id: differLikes.id,
                    useragent: differLikes.useragent
                },
                beforeSend: function () {
                },
                success: function (response) {
                }
            });

        }


    }

    setTimeout(views(), 1000);


}); // jQuery doc ready function







