<?php
/*
Plugin Name: DifferThemes Views
Plugin URI: https://themeforest.net/user/differthemes?rel=DifferThemes
Description: Widgets for Wordpress
Author: DifferThemes
Version: 1.0
License:      GPLv2 or later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  differ_views
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Textdomain
load_plugin_textdomain( 'differ_views', false, basename( dirname( __FILE__ ) ) . '/lang' );

// Script
add_action( 'wp_enqueue_scripts', 'differ_views_add_scripts' );
function differ_views_add_scripts() {
	/** Customizer JS **/
	wp_enqueue_script( 'differ-views-js', plugin_dir_url( __FILE__ ) . '/views.js', array( 'jquery' ) );

	wp_localize_script( 'differ-views-js',
		'differLikes',
		array(
			'ajax_url'  => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'differ-likes' ),
			'id'        => get_the_ID(),
			'useragent' => $_SERVER['HTTP_USER_AGENT']
		) );


}

// PHP Handler
add_action( 'wp_ajax_nopriv_differ_views', 'differ_postviews' );
add_action( 'wp_ajax_differ_views', 'differ_postviews' );

function differ_postviews() {

	$id       = (int) $_POST['id'];
	$meta_key = 'differ_views';
	$cookie   = true;


	if ( function_exists( 'differ_get_option' ) ) {
		$cookie = differ_get_option( 'enable_cookies_views' );
	}


	if ( get_post_meta( $id, $meta_key, true ) ) {
		$views = get_post_meta( $id, $meta_key, true );
	} else {
		$views = 0;
		add_post_meta( $id, $meta_key, $views, true );
	}


	if ( function_exists( 'differ_get_option' ) && ! empty( differ_get_option( 'differ_views' ) ) ) {
		$users = differ_get_option( 'differ_views' );
	} else {
		$users = 'guests';
	}

	if ( $users == 'all' ) {
		$can_update = true;
	} elseif ( $users == 'guests' && ! is_user_logged_in() ) {
		$can_update = true;
	} elseif ( $users == 'logged ' && is_user_logged_in() ) {
		$can_update = true;
	} else {
		$can_update = false;
	}

	// Check google robots
	$useragent = $_POST['useragent'];
	$notbot    = "Mozilla|Opera";
	$bot       = "Bot/|robot|Slurp/|yahoo";
	if ( ! preg_match( "/$notbot/i", $useragent ) || preg_match( "!$bot!i", $useragent ) ) {
		$can_update = false;
	}

	if ( isset( $_COOKIE["differ_views_{$id}"] ) && $_COOKIE["differ_views_{$id}"] == 'visited' ) {
		$can_update = false;
	}

	if ( $can_update ) {
		update_post_meta( $id, $meta_key, ( $views + 1 ) );
		if ( $cookie ) {
			setcookie( "differ_views_{$id}", "visited", time() + 360000, '/', $_SERVER['HTTP_HOST'] );
		}
	}

	die();
}


function differ_get_postviews() {
	$id    = get_the_ID();
	$views = get_post_meta( $id, 'differ_views', true );
	$views = $views ? $views : '0';

	return $views;
}

function differ_the_postviews() {
	echo differ_get_postviews();
}



